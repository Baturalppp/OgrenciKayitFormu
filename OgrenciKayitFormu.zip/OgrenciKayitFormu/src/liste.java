import java.util.ArrayList;
import java.util.List;

public class liste {
     public static List<Ders> tumDersler = new ArrayList<>();
     
}

