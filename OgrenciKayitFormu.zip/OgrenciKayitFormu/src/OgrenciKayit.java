import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class OgrenciKayit extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField ogrenciNoField, ogrenciAdField, ogrenciSoyadField, ogrenciBolumField;
    private JComboBox<String> ogrenciDerslerComboBox;

    public OgrenciKayit() {
        setTitle("Öğrenci Kayıt Formu");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel ogrenciNoLabel = new JLabel("Öğrenci No:");
        JLabel ogrenciAdLabel = new JLabel("Öğrenci Adı:");
        JLabel ogrenciSoyadLabel = new JLabel("Öğrenci Soyadı:");
        JLabel ogrenciBolumLabel = new JLabel("Öğrenci Bölümü:");
        JLabel ogrenciDerslerLabel = new JLabel("Öğrenci Dersleri:");

        ogrenciNoField = new JTextField(15);
        ogrenciAdField = new JTextField(15);
        ogrenciSoyadField = new JTextField(15);
        ogrenciBolumField = new JTextField(15);

        
        ogrenciDerslerComboBox = new JComboBox<>();
        ogrenciDerslerComboBox.addItem("Matematik");
        ogrenciDerslerComboBox.addItem("Kimya");
        ogrenciDerslerComboBox.addItem("Fizik");

        JButton kaydetButton = new JButton("Kaydet");
        kaydetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kaydetButtonActionPerformed(e);
            }
        });

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(ogrenciNoLabel);
        panel.add(ogrenciNoField);
        panel.add(ogrenciAdLabel);
        panel.add(ogrenciAdField);
        panel.add(ogrenciSoyadLabel);
        panel.add(ogrenciSoyadField);
        panel.add(ogrenciBolumLabel);
        panel.add(ogrenciBolumField);
        panel.add(ogrenciDerslerLabel);
        panel.add(ogrenciDerslerComboBox);
        panel.add(new JLabel());
        panel.add(kaydetButton);

        add(panel);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void kaydetButtonActionPerformed(ActionEvent event) {
        String ogrenciNo = ogrenciNoField.getText();
        String ogrenciAd = ogrenciAdField.getText();
        String ogrenciSoyad = ogrenciSoyadField.getText();
        String ogrenciBolum = ogrenciBolumField.getText();
        String ogrenciSeciliDers = (String) ogrenciDerslerComboBox.getSelectedItem();

        if (ogrenciNo.isEmpty() || ogrenciAd.isEmpty() || ogrenciSoyad.isEmpty() || ogrenciBolum.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String dosyaAdi = "ogrenciler.txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dosyaAdi, true))) {
            String kayit = String.format("%s, %s, %s, %s, %s%n", ogrenciNo, ogrenciAd, ogrenciSoyad, ogrenciBolum, ogrenciSeciliDers);
            writer.write(kayit);
            JOptionPane.showMessageDialog(this, "Öğrenci kaydı başarıyla eklendi.", "Başarılı", JOptionPane.INFORMATION_MESSAGE);
            this.dispose(); // Formu kapat
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Dosya yazma hatası.", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new OgrenciKayit();
            }
        });
    }
}
