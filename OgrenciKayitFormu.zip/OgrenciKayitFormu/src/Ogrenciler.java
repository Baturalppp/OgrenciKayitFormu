
public class Ogrenciler {
	    private Integer ogrenciNo;
	    private String ogrenciAdi;
	    private String ogrenciSoyadi;
	    private String ogrenciBolum;
	    private String ogrenciDersi;

	    public Ogrenciler(Integer ogrenciNo, String ogrenciAdi, String ogrenciSoyadi, String ogrenciBolum, String ogrenciDersi) {
	        this.ogrenciNo = ogrenciNo;
	        this.ogrenciAdi = ogrenciAdi;
	        this.ogrenciSoyadi = ogrenciSoyadi;
	        this.ogrenciBolum = ogrenciBolum;
	        this.ogrenciDersi = ogrenciDersi;
	    }

	    public Integer getOgrenciNo() {
	        return ogrenciNo;
	    }

	    public String getOgrenciAdi() {
	        return ogrenciAdi;
	    }

	    public String getOgrenciSoyadi() {
	        return ogrenciSoyadi;
	    }

	    public String getOgrenciBolum() {
	        return ogrenciBolum;
	    }

	    public String getOgrenciDersi() {
	        return ogrenciDersi;
	    }

	    @Override
	    public String toString() {
	        return "Ogrenci{" +
	                "ogrenciNo='" + ogrenciNo + '\'' +
	                ", ogrenciAdi='" + ogrenciAdi + '\'' +
	                ", ogrenciSoyadi='" + ogrenciSoyadi + '\'' +
	                ", ogrenciBolum='" + ogrenciBolum + '\'' +
	                ", ogrenciDersi='" + ogrenciDersi + '\'' +
	                '}';
	    }
}
